ROADWISE PH - XAMPP SETUP
=========================
1. Install Python 3.10+ (tick "Add Python to PATH") and XAMPP.
2. Open the XAMPP Control Panel and click START next to MySQL (Apache is only needed for phpMyAdmin).
3. Double-click 123.bat. First run installs pymysql + Pillow and the app creates the
   database "roadwise" with all tables by itself.
   (Alternative: phpMyAdmin -> Import -> roadwise_schema.sql)
4. Log in as admin@roadwise.ph / admin123 (change it afterwards), or create an account.

Optional: python migrate_sqlite_to_mysql.py   (copies the old roadwise.db accounts/trips into MySQL; needs roadwise.db beside it)
Check the connection:  python roadwise_app.py --dbcheck
Settings (host/port/user/password/database): roadwise_db.json  (XAMPP defaults: root, empty password)

DELETING AN ACCOUNT
phpMyAdmin -> roadwise -> users -> tick the row -> Delete.
The app checks every ~3 seconds: that user is sent back to the login screen, cannot log in
again, and cannot save trips or hazards. Their trips are deleted with them.
Add an account by hand: INSERT INTO users (name,email,password,role)
  VALUES ('Name','me@x.com',SHA2('thePassword',256),'user');   -- email must be lowercase
