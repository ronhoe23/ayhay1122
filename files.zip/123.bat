@echo off
TITLE RoadWise PH - Python App Launcher
COLOR 0A
cd /d "%~dp0"
echo ===================================================
echo     ROADWISE PH - PURE PYTHON APP LAUNCHER
echo ===================================================
echo.
echo Make sure XAMPP is running: open the XAMPP Control Panel and
echo click Start next to MySQL before using the app.
echo.
python -c "import pymysql, PIL" 2>nul
if errorlevel 1 (
    echo Installing required Python packages ^(first run only^)...
    python -m pip install -r requirements.txt
    echo.
)
echo Starting application window...
python roadwise_app.py
pause
