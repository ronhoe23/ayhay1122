-- RoadWise PH - database for XAMPP (MySQL / MariaDB)
-- Import with phpMyAdmin: http://localhost/phpmyadmin -> Import -> choose this file -> Go.
-- (Optional: the app creates all of this by itself the first time it starts.)

CREATE DATABASE IF NOT EXISTS `roadwise` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `roadwise`;

CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(190) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL DEFAULT 'user',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `hazards` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(200) NOT NULL,
  `desc` TEXT NOT NULL,
  `lat` DOUBLE NULL,
  `lng` DOUBLE NULL,
  `type` VARCHAR(50) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Deleting a user also deletes that user's trips, and MySQL itself refuses to
-- store a trip for a user that no longer exists.
CREATE TABLE IF NOT EXISTS `trips` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NULL,
  `start` VARCHAR(120) NOT NULL,
  `end` VARCHAR(120) NOT NULL,
  `mode` VARCHAR(60) NOT NULL,
  `traffic` VARCHAR(60) NULL,
  `fare` DOUBLE NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_trips_user` (`user_id`),
  CONSTRAINT `fk_trips_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Remembers that the default admin / sample hazards were already created once,
-- so deleting them later does not bring them back.
CREATE TABLE IF NOT EXISTS `app_meta` (
  `k` VARCHAR(50) NOT NULL,
  `v` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin: admin@roadwise.ph / admin123  (change the password after first login)
INSERT IGNORE INTO `users` (`name`, `email`, `password`, `role`)
VALUES ('Admin User', 'admin@roadwise.ph', SHA2('admin123', 256), 'admin');

INSERT INTO `hazards` (`title`, `desc`, `lat`, `lng`, `type`)
SELECT * FROM (
  SELECT 'Heavy Jam near EDSA Ortigas' AS t, 'Slow traffic southbound.' AS d, 14.5855 AS la, 121.0565 AS lo, 'Hazard' AS ty
  UNION ALL
  SELECT 'Construction on Marikina Bridge', 'Outer lane blocked for repairs.', 14.6330, 121.0960, 'Hazard'
) AS seed
WHERE NOT EXISTS (SELECT 1 FROM `hazards`);

INSERT IGNORE INTO `app_meta` (`k`, `v`) VALUES ('seeded', '1');
