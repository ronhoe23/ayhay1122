"""One-time copy of the OLD SQLite database (roadwise.db) into the XAMPP MySQL database.

    python migrate_sqlite_to_mysql.py

Safe to run more than once: rows that already exist (same id / same email) are skipped.
Old SHA-256 passwords keep working and are upgraded to a salted hash at the next login.
"""
import os
import sqlite3
import sys

import rw_db as DB

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "roadwise.db")


def main():
    if not os.path.exists(SRC):
        print("No roadwise.db next to this script - nothing to migrate.")
        return 0
    DB.init_schema()
    old = sqlite3.connect("file:%s?mode=ro" % SRC.replace("\\", "/"), uri=True)
    conn = DB.connect()
    counts = {"users": 0, "hazards": 0, "trips": 0}
    try:
        cur = conn.cursor()
        for r in old.execute("SELECT id,name,email,password,role,created_at FROM users"):
            cur.execute("INSERT IGNORE INTO `users` (`id`,`name`,`email`,`password`,`role`,"
                        "`created_at`) VALUES (%s,%s,%s,%s,%s,%s)", r)
            counts["users"] += cur.rowcount
        for r in old.execute("SELECT id,title,desc,lat,lng,created_at,type FROM hazards"):
            cur.execute("INSERT IGNORE INTO `hazards` (`id`,`title`,`desc`,`lat`,`lng`,"
                        "`created_at`,`type`) VALUES (%s,%s,%s,%s,%s,%s,%s)", r)
            counts["hazards"] += cur.rowcount
        cur.execute("SELECT `id` FROM `users`")
        valid = {row[0] for row in cur.fetchall()}
        for r in old.execute("SELECT id,user_id,start,end,mode,traffic,fare,created_at "
                             "FROM trips"):
            if r[1] not in valid:
                print("  skipped trip %s (its user does not exist)" % r[0])
                continue
            cur.execute("INSERT IGNORE INTO `trips` (`id`,`user_id`,`start`,`end`,`mode`,"
                        "`traffic`,`fare`,`created_at`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)", r)
            counts["trips"] += cur.rowcount
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
        old.close()
    print("Copied:", counts)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except DB.DBError as e:
        print("FAILED:", e)
        sys.exit(1)
