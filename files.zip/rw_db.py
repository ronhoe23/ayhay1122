"""RoadWise PH - MySQL / XAMPP data layer.

Everything the app stores (users, hazards, trips) lives in a MySQL database
served by XAMPP.  Connection settings come from roadwise_db.json (created next
to the app on first run, with the XAMPP defaults), and can be overridden with
the environment variables RW_DB_HOST / RW_DB_PORT / RW_DB_USER /
RW_DB_PASSWORD / RW_DB_NAME.

Every call opens its own short-lived connection, so it is safe to call from
the Tk thread and from worker threads at the same time, and nothing is left
open that could hold a lock when someone edits the data in phpMyAdmin.
"""
import hashlib
import hmac
import json
import os
import re

try:
    import pymysql
except ImportError:  # reported with a friendly message by connect()
    pymysql = None

import rw_data as RWD

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "roadwise_db.json")

# XAMPP's out-of-the-box MySQL/MariaDB: user "root", empty password, port 3306.
DEFAULTS = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "",
    "database": "roadwise",
}

ERR_DUP_ENTRY = 1062
ERR_NO_REFERENCED_ROW = 1452
ERR_UNKNOWN_DB = 1049


class DBError(Exception):
    """Any database problem, with a message that is safe to show to the user."""

    def __init__(self, message, code=None):
        super().__init__(message)
        self.code = code


class DuplicateEmail(DBError):
    pass


class UserGone(DBError):
    """The account this action belongs to no longer exists in the database."""


# --------------------------------------------------------------------------
# configuration
# --------------------------------------------------------------------------
_cfg_cache = None


def get_config(reload=False):
    global _cfg_cache
    if _cfg_cache is not None and not reload:
        return _cfg_cache
    cfg = dict(DEFAULTS)
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            cfg.update({k: data[k] for k in DEFAULTS if k in data})
    except FileNotFoundError:
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
                json.dump(DEFAULTS, fh, indent=2)
        except OSError:
            pass
    except (OSError, ValueError):
        pass  # unreadable/invalid file: fall back to the defaults
    env = {"host": "RW_DB_HOST", "port": "RW_DB_PORT", "user": "RW_DB_USER",
           "password": "RW_DB_PASSWORD", "database": "RW_DB_NAME"}
    for key, var in env.items():
        if os.environ.get(var) is not None:
            cfg[key] = os.environ[var]
    try:
        cfg["port"] = int(cfg["port"])
    except (TypeError, ValueError):
        cfg["port"] = 3306
    cfg["password"] = "" if cfg["password"] is None else str(cfg["password"])
    if not re.fullmatch(r"[A-Za-z0-9_]{1,64}", str(cfg["database"])):
        raise DBError("The database name in roadwise_db.json may only contain letters, "
                      "digits and underscores.")
    _cfg_cache = cfg
    return cfg


def describe():
    c = get_config()
    return "%s@%s:%s/%s" % (c["user"], c["host"], c["port"], c["database"])


def _friendly(exc, cfg):
    code = exc.args[0] if exc.args and isinstance(exc.args[0], int) else None
    if code in (2002, 2003, 2013, 2006) or code is None and isinstance(exc, OSError):
        return ("Cannot reach MySQL at %s:%s.\n\nOpen the XAMPP Control Panel and click "
                "Start next to MySQL, then try again." % (cfg["host"], cfg["port"]))
    if code == 1045:
        return ("MySQL refused the user name or password.\n\nCheck \"user\" and "
                "\"password\" in roadwise_db.json (XAMPP's default is user root with an "
                "empty password).")
    if code == ERR_UNKNOWN_DB:
        return "The database \"%s\" does not exist yet." % cfg["database"]
    text = exc.args[1] if len(exc.args) > 1 else str(exc)
    return "MySQL error %s: %s" % (code if code is not None else "?", text)


def connect(use_db=True):
    if pymysql is None:
        raise DBError("The 'pymysql' package is not installed.\n\nOpen a terminal and run:\n"
                      "    python -m pip install pymysql")
    cfg = get_config()
    try:
        return pymysql.connect(
            host=cfg["host"], port=cfg["port"], user=cfg["user"], password=cfg["password"],
            database=cfg["database"] if use_db else None, charset="utf8mb4",
            connect_timeout=5, read_timeout=15, write_timeout=15, autocommit=False)
    except (pymysql.MySQLError, OSError) as e:
        code = e.args[0] if e.args and isinstance(e.args[0], int) else None
        raise DBError(_friendly(e, cfg), code) from e


def _run(sql, params=(), mode="all"):
    conn = connect()
    try:
        cur = conn.cursor()
        try:
            cur.execute(sql, params)
            if mode == "all":
                result = list(cur.fetchall())
            elif mode == "one":
                result = cur.fetchone()
            else:
                result = cur.lastrowid
        finally:
            cur.close()
        conn.commit()
        return result
    except (pymysql.MySQLError, OSError) as e:
        code = e.args[0] if e.args and isinstance(e.args[0], int) else None
        raise DBError(_friendly(e, get_config()), code) from e
    finally:
        try:
            conn.close()
        except Exception:
            pass


def query_all(sql, params=()):
    return _run(sql, params, "all")


def query_one(sql, params=()):
    return _run(sql, params, "one")


def execute(sql, params=()):
    """Run INSERT/UPDATE/DELETE; returns lastrowid."""
    return _run(sql, params, "exec")


# --------------------------------------------------------------------------
# passwords
# --------------------------------------------------------------------------
_ITERATIONS = 200000
_LEGACY = re.compile(r"[0-9a-f]{64}")


def hash_password(password):
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"), salt, _ITERATIONS)
    return "pbkdf2_sha256$%d$%s$%s" % (_ITERATIONS, salt.hex(), dk.hex())


def legacy_hash(password):
    """Plain SHA-256 hex, the format the first version of the app (and a phpMyAdmin
    SHA2('...',256) insert) uses.  Still accepted at login, then upgraded."""
    return hashlib.sha256((password or "").encode("utf-8")).hexdigest()


def verify_password(password, stored):
    """Returns (ok, needs_upgrade)."""
    stored = stored or ""
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, iters, salt, digest = stored.split("$")
            dk = hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                                     bytes.fromhex(salt), int(iters))
            return hmac.compare_digest(dk.hex(), digest), False
        except (ValueError, TypeError):
            return False, False
    if _LEGACY.fullmatch(stored.lower()):
        return hmac.compare_digest(legacy_hash(password), stored.lower()), True
    return False, False


# --------------------------------------------------------------------------
# schema
# --------------------------------------------------------------------------
SCHEMA = [
    """CREATE TABLE IF NOT EXISTS `users` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `name` VARCHAR(100) NOT NULL,
        `email` VARCHAR(190) NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `role` VARCHAR(20) NOT NULL DEFAULT 'user',
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_users_email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS `hazards` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `title` VARCHAR(200) NOT NULL,
        `desc` TEXT NOT NULL,
        `lat` DOUBLE NULL,
        `lng` DOUBLE NULL,
        `type` VARCHAR(50) NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS `trips` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED NULL,
        `start` VARCHAR(120) NOT NULL,
        `end` VARCHAR(120) NOT NULL,
        `mode` VARCHAR(60) NOT NULL,
        `traffic` VARCHAR(60) NULL,
        `fare` DOUBLE NOT NULL,
        `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_trips_user` (`user_id`),
        CONSTRAINT `fk_trips_user` FOREIGN KEY (`user_id`)
            REFERENCES `users` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS `app_meta` (
        `k` VARCHAR(50) NOT NULL,
        `v` VARCHAR(255) NOT NULL,
        PRIMARY KEY (`k`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
]


def _open_for_setup():
    """Connect to the app database, creating it first when it does not exist."""
    cfg = get_config()
    try:
        return connect(use_db=True)
    except DBError as e:
        if e.code != ERR_UNKNOWN_DB:
            raise
    conn = connect(use_db=False)
    try:
        cur = conn.cursor()
        cur.execute("CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 "
                    "COLLATE utf8mb4_unicode_ci" % cfg["database"])
        cur.close()
        conn.commit()
    except pymysql.MySQLError as e:
        conn.close()
        code = e.args[0] if e.args and isinstance(e.args[0], int) else None
        raise DBError("Could not create the database \"%s\": %s" % (
            cfg["database"], _friendly(e, cfg)), code) from e
    conn.close()
    return connect(use_db=True)


def init_schema():
    """Create the database and tables if needed and seed the default admin and the
    sample hazards exactly once.

    Seeding is remembered in app_meta, so deleting the admin account (or every
    hazard) in phpMyAdmin does NOT bring it back the next time the app starts.
    """
    conn = _open_for_setup()
    try:
        cur = conn.cursor()
        for stmt in SCHEMA:
            cur.execute(stmt)
        cur.execute("SELECT `v` FROM `app_meta` WHERE `k`=%s", ("seeded",))
        if cur.fetchone() is None:
            cur.execute("INSERT IGNORE INTO `users` (`name`,`email`,`password`,`role`) "
                        "VALUES (%s,%s,%s,%s)",
                        ("Admin User", "admin@roadwise.ph", hash_password("admin123"), "admin"))
            cur.execute("SELECT COUNT(*) FROM `hazards`")
            if cur.fetchone()[0] == 0:
                cur.executemany("INSERT INTO `hazards` (`title`,`desc`,`lat`,`lng`,`type`) "
                                "VALUES (%s,%s,%s,%s,%s)",
                                [(t, d, la, lo, "Hazard") for t, d, la, lo in RWD.SEED_HAZARDS])
            cur.execute("INSERT INTO `app_meta` (`k`,`v`) VALUES (%s,%s)", ("seeded", "1"))
        cur.close()
        conn.commit()
    except (pymysql.MySQLError, OSError) as e:
        conn.rollback()
        code = e.args[0] if e.args and isinstance(e.args[0], int) else None
        raise DBError(_friendly(e, get_config()), code) from e
    finally:
        try:
            conn.close()
        except Exception:
            pass


# --------------------------------------------------------------------------
# users
# --------------------------------------------------------------------------
def _user(row):
    return {"id": int(row[0]), "name": row[1], "email": row[2],
            "role": (row[3] or "user").strip().lower()}


def get_user(uid):
    """The live row for this account, or None when it has been deleted."""
    row = query_one("SELECT `id`,`name`,`email`,`role` FROM `users` WHERE `id`=%s", (uid,))
    return _user(row) if row else None


def verify_login(email, password):
    """The user dict when email+password match an existing account, else None."""
    row = query_one("SELECT `id`,`name`,`email`,`role`,`password` FROM `users` "
                    "WHERE `email`=%s", (email,))
    if not row:
        return None
    ok, upgrade = verify_password(password, row[4])
    if not ok:
        return None
    if upgrade:
        try:
            execute("UPDATE `users` SET `password`=%s WHERE `id`=%s",
                    (hash_password(password), row[0]))
        except DBError:
            pass  # the login itself is still valid
    return _user(row)


def create_user(name, email, password):
    try:
        uid = execute("INSERT INTO `users` (`name`,`email`,`password`) VALUES (%s,%s,%s)",
                      (name, email, hash_password(password)))
    except DBError as e:
        if e.code == ERR_DUP_ENTRY:
            raise DuplicateEmail("That email already has an account.", e.code) from e
        raise
    return {"id": int(uid), "name": name, "email": email, "role": "user"}


# --------------------------------------------------------------------------
# hazards, trips, admin view
# --------------------------------------------------------------------------
def list_hazards():
    rows = query_all("SELECT `id`,`title`,`desc`,`lat`,`lng` FROM `hazards` ORDER BY `id` DESC")
    return [{"id": int(r[0]), "title": r[1], "desc": r[2],
             "lat": None if r[3] is None else float(r[3]),
             "lng": None if r[4] is None else float(r[4])} for r in rows]


def add_hazard(title, desc, lat, lng):
    return execute("INSERT INTO `hazards` (`title`,`desc`,`lat`,`lng`,`type`) "
                   "VALUES (%s,%s,%s,%s,%s)", (title, desc, lat, lng, "Hazard"))


def add_trip(user_id, start, end, mode, traffic, fare):
    try:
        return execute("INSERT INTO `trips` (`user_id`,`start`,`end`,`mode`,`traffic`,`fare`) "
                       "VALUES (%s,%s,%s,%s,%s,%s)",
                       (user_id, start, end, mode, traffic, float(fare)))
    except DBError as e:
        if e.code == ERR_NO_REFERENCED_ROW:
            raise UserGone("This account no longer exists.", e.code) from e
        raise


def recent_trips(user_id, is_admin, limit=40):
    cols = "`start`,`end`,`mode`,`traffic`,`fare`,`created_at`"
    if is_admin:
        return query_all("SELECT %s FROM `trips` ORDER BY `id` DESC LIMIT %%s" % cols, (limit,))
    return query_all("SELECT %s FROM `trips` WHERE `user_id`=%%s ORDER BY `id` DESC LIMIT %%s"
                     % cols, (user_id, limit))


def admin_snapshot():
    return {
        "users": query_all("SELECT `id`,`name`,`email`,`role`,`created_at` FROM `users` "
                           "ORDER BY `id`"),
        "hazards": query_all("SELECT `id`,`title`,`desc`,`lat`,`lng` FROM `hazards` "
                             "ORDER BY `id`"),
        "trips": query_all("SELECT `id`,`user_id`,`start`,`end`,`mode`,`traffic`,`fare`,"
                           "`created_at` FROM `trips` ORDER BY `id`"),
    }
